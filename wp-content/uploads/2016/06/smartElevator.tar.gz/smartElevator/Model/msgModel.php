<?php
namespace Model;
//descomentar a linha abaixo para testar a classe diretamente, sem usar phpunit
//require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use).

use ADO\msgADO, ADO\tbPropriedades;
/**
 * Description of andarModel
 *
 * @author tatuapu
 */
class msgModel {
    private $objMsgADO;
    private $tbPropriedades;
    
    public function __construct() {
        $this->objMsgADO = new msgADO();
        $t = new tbPropriedades();
        $this->tbPropriedades = $t->getTbPropriedades('msg');//carregando propriedades da tabela
    }
    public function setMsg($msg,$idChamada){
        return $this->objMsgADO->setMsg($msg, $idChamada);
    }
    public function pegaUltimaMsgAndar($idAndar){
        return $this->objMsgADO->pegaUltimaMsgAndar($idAndar);
    }
}
