<?php
namespace Model;
//descomentar a linha abaixo para testar a classe diretamente, sem usar phpunit
//require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use).

use ADO\andarADO, ADO\tbPropriedades;
/**
 * Description of andarModel
 *
 * @author tatuapu
 */
class andarModel {
    private $objAndarADO;
    private $tbPropriedades;
    
    public function __construct() {
        $this->objAndarADO = new andarADO();
        $this->tbPropriedades = new tbPropriedades();//instanciando obj
        $this->tbPropriedades = $this->tbPropriedades->getTbPropriedades();//sobrescrevendo com o conteúdo
    }
    /**
     * método que recebe os ids dos andares, sendo o primeiro o andar que se
     * encontra o elevador, e o segundo o do andar que fez a chamada
     * retorna o número de andares a se locomover para chegar ao destino.
     * Se o número retornado for positivo, o elevador deve descer, ou subir
     * caso o retorno for positivo
     * @param int $idAndarElevador
     * @param int $idAndarChamada
     */
    public function calculaAndares($idAndarElevador,$idAndarChamada){
        $nroAndarElevador = $this->objAndarADO->getNroAndar($idAndarElevador);
        $nroAndarChamada = $this->objAndarADO->getNroAndar($idAndarChamada);
        return $nroAndarElevador - $nroAndarChamada;
    }
    public function getNroAndar($id){
        return $this->objAndarADO->getNroAndar($id);
    }
    public function getIdAndar($nro){
        return $this->objAndarADO->getIdAndar($nro);
    }
    public function getAllAndares(){
        return $this->objAndarADO->pegaTodosAndares();
    }
    public function getUltimoAndar(){
        return $this->objAndarADO->pegaUltimoAndar();
    }
    public function getPrimeiroAndar(){
        return $this->objAndarADO->pegaPrimeiroAndar();
    }
}
