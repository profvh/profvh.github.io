<?php

namespace Model;

//descomentar a linha abaixo para testar a classe diretamente, sem usar phpunit
//require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use).

use ADO\chamadaADO, ADO\tbPropriedades;

class chamadaModel
{
    private $objChamadaADO;
    private $tbPropriedades;
    
    public function __construct() {
        $this->objChamadaADO = new chamadaADO();
        $this->tbPropriedades = new tbPropriedades();//instanciando obj
        $this->tbPropriedades = $this->tbPropriedades->getTbPropriedades();//sobrescrevendo com o conteúdo
    }
    
    public function pegaChamadasNovas(){
        return $this->objChamadaADO->pegaTodasNovas();//recebe um fetchAll
    }
    public function criaChamada($idAndar,$tpChamada,$idElevSelecionado){
        return $this->objChamadaADO->criaChamada($idAndar, $tpChamada, $idElevSelecionado);
    }
    public function pegaUltimaChamadaNovaIdAndar($idAndar){
        return $this->objChamadaADO->pegaUltimaChamadaNovaIdAndar($idAndar);
    }
    /**
     * Método que altera o status de uma chamada Nova para Em Curso
     * chamada quando o elevador chega ao andar de uma chamada e pega o passageiro
     * @param idChamada carrega o id da chamada a ser alterada
     * @return retorna 1 (transação efetuada com sucesso) ou 0 (erro/falha)
     */
    public function setChamadaEmCurso($idChamada){
        return $this->objChamadaADO->setChamadaEmCurso($idChamada);
    }
    /**
     * Método que altera o status de uma chamada Em Curso para Concluída
     * chamada quando o elevador chega ao andar de destino, encerrando a viagem
     * @param idChamada carrega o id da chamada a ser alterada
     * @return retorna 1 (transação efetuada com sucesso) ou 0 (erro/falha)
     */
    public function setChamadaConcluida($idChamada){
        return $this->objChamadaADO->setChamadaConcluida($idChamada);
    }
    public function getUltimaChamadaCriada(){
        return $this->objChamadaADO->getUltimaChamadaCriada();
    }
}
