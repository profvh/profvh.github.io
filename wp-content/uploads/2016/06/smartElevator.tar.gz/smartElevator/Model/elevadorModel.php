<?php

namespace Model;

//descomentar a linha abaixo para testar a classe diretamente, sem usar phpunit
//require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use).

use ADO\elevadorADO,    ADO\tbPropriedades;

class elevadorModel
{
    private $objElevadorADO;
    private $tbPropriedades;
    
    public function __construct() {
        $this->objElevadorADO = new elevadorADO();
        $this->tbPropriedades = new tbPropriedades();//instanciando obj
        $this->tbPropriedades = $this->tbPropriedades->getTbPropriedades();//sobrescrevendo com o conteúdo
    }
    
    public function getElevadoresAtivos(){
        return $this->objElevadorADO->pegaElevadoresAtivos();//recebe um fetchAll
    }
    /**
    * Description of setElevadorSelecionado
    * Método chamado após a escolha do elevador
    * envia o idElevador, 
    * e altera o status para "Bloqueado"
    * não retorna nada
    */
    public function setElevadorSelecionado($elevadorSelecionado){
        return $this->objElevadorADO->setStatusElevador("Bloqueado", $elevadorSelecionado);
    }
    /**
     * Altera o statusElevador de Bloqueado para Ativo
     * @param int $id idElevador Selecionado
     * @return int 0 para erro, ou o número de affected_rows, esperado 1
     */
    public function liberaElevadorSelecionado($id){
        return $this->objElevadorADO->setStatusElevador("Ativo", $id);
    }    
    /**
    * Description of setElevadorMovimentando
    * Método chamado assim que o elevador vai entrar em movimento
    * envia o idElevador, 
    * e altera o status para "Subindo" ou "Descendo"
    * não retorna nada
    */
    public function setElevadorMovimentando($elevadorSelecionado,$nStatus){
        return $this->objElevadorADO->setStatusElevador($nStatus, $elevadorSelecionado);
    }
    /**
     * atualiza o andar atual do elevador em qualquer movimento.
     * Como cada elevador anda andar por andar, basta informar se é subida
     * ou descida, para atualizar o andar ++ ou --
     * @param string $tp
     * @param int idElevador
     * @return int, sendo o id do novo andar do elevador, ou 0 caso erro
     */
    public function changeAndarElevador($tp,$idElevador){
        if($tp =="Subir"){
            return $this->objElevadorADO->sobeElevador($idElevador);
        }else{
            return $this->objElevadorADO->desceElevador($idElevador);
        }
    }
    public function getElevadorEspecifico($id){
        return $this->objElevadorADO->pegaElevadorEspecifico($id);
    }
    public function getStatusElevadorEspecifico($id){
        return $this->objElevadorADO->getStatusElevador($id);
    }
    public function getAllElevadores(){
        return $this->objElevadorADO->pegaTodosElevadores();
    }
    public function getElevadorBloqueadoAndar($idAndar){
        return $this->objElevadorADO->getElevadorBloqueadoAndar($idAndar);
    }
}
