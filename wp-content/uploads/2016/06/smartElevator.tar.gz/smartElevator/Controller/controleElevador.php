<?php

/**
 * Description of controleElevador
 * Carregador do módulo de inicialização do controller do elevador
 * recebe a ação requerida e os parâmetros de inicialização
 * instancia um objeto do controller, que toma conta da solicitação
 * @author tatuapu
 */

//descomentar a linha abaixo para testar a classe diretamente, sem usar phpunit
//require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use). 
require_once("elevadorController.php");

use Controller\elevadorController;

//solicitação enviada por http. Ex.: action:"chamarElevador",tp:tpChamada,andar:nrAndar
/* @var $_POST type action recebe a ação requerida pelo chamador*/
$action   = $_REQUEST['action'];
$tpChamada= $_REQUEST['tp'];
$andar    = $_REQUEST['andar'];

$objControllerElevador =  new elevadorController($action,$tpChamada,$andar);
//devolvendo ao ajax o id do elevador selecionado
echo $objControllerElevador->getElevadorSelecionado();

unset($objControllerElevador);//destroy object

