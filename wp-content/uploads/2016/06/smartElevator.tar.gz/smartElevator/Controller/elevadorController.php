<?php
namespace Controller;

//descomentar a linha abaixo para testar a classe diretamente, sem usar phpunit
require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use).

use Model\elevadorModel, ADO\andarADO, Model\chamadaModel, classes\elevador, classes\timer, Model\andarModel, Model\msgModel;
/**
 * Description of elevadorController
 *
 * @author tatuapu
 */
class elevadorController {
    
    private $action = null;
    private $tpChamada = null;
    private $andar = null;
    private $idAndarDestino = 0;
    private $objElevadorModel;
    private $objChamadaModel;
    private $objAndarModel;
    private $elevadorSelecionado = 0;//armazena o id do elevador selecionado
    private $msgPainel = null;
    private $objTimer;
    private $objMsgModel;
    private $idChamada;
    
    public function __construct($action=null,$tpChamada=null,$andar=null) {
        $this->tpChamada = $tpChamada; //Subir ou Descer
        $this->andar = $andar;
        $this->action = $action;
        $this->objElevadorModel = new elevadorModel();
        $this->objChamadaModel = new chamadaModel();
        $this->objMsgModel = new msgModel();
        switch ($action){
            case "chamarElevador":
                $this->chamarElevador();
                break;
        }
    }
    public function getStatusConvertido(){
        $ns = ($this->tpChamada == "Subir") ? "Subindo" : "Descendo";
        return $ns;
    }
    public function changeMsg($msg){
        $this->msgPainel = $msg;
        $this->objMsgModel->setMsg($msg, $this->idChamada);
    }
    public function chamarElevador(){
        $this->elevadorSelecionado = 0; 
        $idEPx = 0;//armazenar elevador mais próximo idElevador
        $ePx = 100000; //armazena o andar do elevador mais próximo, pro cálculo
        $elevadoresAtivos = $this->objElevadorModel->getElevadoresAtivos();
       
        foreach($elevadoresAtivos as $eA){//varrendo os elevadores ativos para descobrir o mais próximo da chamada
            //fazendo uma subtração simples para descobrir quem está mais próximo do chamado
            $sub = $eA["nroAndar"] - $this->andar;
            $sub = ($sub<0) ? $sub*(-1) : $sub; //módulo da subtração (só positivos)
            
            if($sub<$ePx){
                $ePx  = $sub;
                $idEPx= $eA["idElevador"];
            }
        }
        $this->elevadorSelecionado = $idEPx;
        
        //Bloqueando o elevador selecionado
        if($this->elevadorSelecionado !== 0){
            $this->objElevadorModel->setElevadorSelecionado($this->elevadorSelecionado);           
            $rTpC = $this->objChamadaModel->criaChamada($this->andar, $this->tpChamada, $this->elevadorSelecionado);
            $this->idChamada = $this->objChamadaModel->getUltimaChamadaCriada();//pegando o last id
            $this->changeMsg("Elevador Bloqueado Para Envio");
            if ($rTpC > 0){//para maior que 0, foi criada corretamente                
                $this->changeMsg("Elevador a Caminho");
                //comandar a movimentação do elevador até o andar da solicitação
                $this->movimentarElevadorAteSolicitacao();
                $this->changeMsg("Elevador Chegou");
                $this->aguardaPassageiro();
            }
        }else{
            $this->changeMsg("Nenhum Elevador Disponível");
        }       
    }
    public function setIdAndarDestino($id){
        $this->idAndarDestino = $id;
    }
    public function setElevadorSelecionado($id){
        $this->elevadorSelecionado = $id;
    }
    /**
     * Description of levarElevador
     * método que coordena a transição do elevador do andar em que se encontra
     * ao andar solicitado pelo passageiro.
     * Exite que seja informado corretamente i andar de destino e elevador selecionado
     * @return false caso não tenha sido setado corretamente o elevador selecionado
     * e o idAndarDestino, true caso operação tenha ocorrido com sucesso!
     */
   public function levarElevador(){
        $this->setIdChamada($this->objChamadaModel->pegaUltimaChamadaNovaIdAndar($this->andar));
        
        //alterando status da chamada
        $this->objChamadaModel->setChamadaEmCurso($this->idChamada);
        
        if ($this->elevadorSelecionado != 0 && $this->idAndarDestino != 0){
            $this->objAndarModel = new andarModel();
            //capturando dados do elevador selecionado
            $r = $this->objElevadorModel->getElevadorEspecifico($this->elevadorSelecionado);

            //criando objeto elevador com os dados carregados do BD
            $elevador1 = new elevador([$this->elevadorSelecionado,$r[0][1],$r[0][2],$r[0][3],$r[0][4],$r[0][5],$r[0][6],$r[0][7]]);
            //instanciando o Timer, pra controlar a movimentação em tempo do elevador
            $this->objTimer = new timer();
            //calculando a diferença de andares entre o andar que sem encontra e o andar destino
            //recebe a quantidade de andares a se locomover. 
            //Retorno positivo: elevador deve descer, e subir caso seja negativo
            $qtdAndares = $this->objAndarModel->calculaAndares($elevador1->getIdAndar(),$this->idAndarDestino);
            //pegando a velocidade do elevador, segundo o retorno da qtd de andares
            if($qtdAndares < 0){//subir
                $velocidade = $elevador1->getVlSubida();
                $qtdAndares*=-1;//módulo
                //altera status do elevador selecionado para "Subindo" ou "Descendo"
                $this->objElevadorModel->setElevadorMovimentando($this->elevadorSelecionado, "Subindo");
                $this->changeMsg("Elevador Subindo");
                //movendo o elevador ao seu destino
                for ($i=0;$i<$qtdAndares;$i++){
                    $this->objTimer->start($velocidade);
                    $nIdE = $this->objElevadorModel->changeAndarElevador("Subir",$this->elevadorSelecionado);
                }
            }else{//descer
                $velocidade = $elevador1->getVlDescida();
                //movendo o elevador ao seu destino
                //altera status do elevador selecionado para "Subindo" ou "Descendo"
                $this->objElevadorModel->setElevadorMovimentando($this->elevadorSelecionado, "Descendo");
                $this->changeMsg("Elevador Descendo");
                for ($i=$qtdAndares;$i>0;$i--){                
                    $this->objTimer->start($velocidade);
                    $nIdE = $this->objElevadorModel->changeAndarElevador("Descer",$this->elevadorSelecionado);
                }
            $this->changeMsg("Elevador Chegou");
            $this->aguardaPassageiro();
            //alterando status da chamada
            $this->objChamadaModel->setChamadaConcluida($this->idChamada);
            }
            return true;
        }else{
            return false;
        }
    }
    
    /**
     * Description of movimentarElevadorAteSolicitacao
     * método que coordena a transição do elevador definido para o transporte
     * do andar em que se encontra, até o andar onde há uma solicitação
     * @param são buscados nos parâmetros de instância
     * @return não retorna nada
     */
    private function movimentarElevadorAteSolicitacao(){
        $nIdE = 0;
        $this->objAndarModel = new andarModel();
        //capturando dados do elevador selecionado
        $r = $this->objElevadorModel->getElevadorEspecifico($this->elevadorSelecionado);
        
        //criando objeto elevador com os dados carregados do BD
        $elevador1 = new elevador([$this->elevadorSelecionado,$r[0][1],$r[0][2],$r[0][3],$r[0][4],$r[0][5],$r[0][6],$r[0][7]]);
        //instanciando o Timer, pra controlar a movimentação em tempo do elevador
        $this->objTimer = new timer();
        //calculando a diferença de andares entre o andar que sem encontra e o andar do solicitante
        //recebe a quantidade de andares a se locomover. 
        //Retorno positivo: elevador deve descer, e subir caso seja negativo
        $qtdAndares = $this->objAndarModel->calculaAndares($elevador1->getIdAndar(),$this->andar);
        
        //pegando a velocidade do elevador, segundo o retorno da qtd de andares
        if($qtdAndares < 0){
            $velocidade = $elevador1->getVlSubida();
            $qtdAndares*=-1;
            //movendo o elevador ao seu destino
            for ($i=0;$i<$qtdAndares;$i++){
                $this->objTimer->start($velocidade);
                $nIdE = $this->objElevadorModel->changeAndarElevador("Subir",$this->elevadorSelecionado);
            }
        }else{
            $velocidade = $elevador1->getVlDescida();
            //movendo o elevador ao seu destino
            for ($i=$qtdAndares;$i>0;$i--){                
                $this->objTimer->start($velocidade);
                $nIdE = $this->objElevadorModel->changeAndarElevador("Descer",$this->elevadorSelecionado);
            }
        }        
    }
    public function aguardaPassageiro(){
        //ao chegar no local chamado, o elevador fica "Bloqueado" por 20 segundos
        //aguardando a entrada do passageiro
        //instanciando o Timer, pra controlar o tempo de espera
        $this->objTimer = new timer();
        $this->objTimer->start(20);
        //passado o tempo determinado de espera, caso não tenha sido informada
        //nenhuma ação ao elevador, seu status será alterado para "Ativo"
        
        //checando status do elevador
        $status = $this->objElevadorModel->getStatusElevadorEspecifico($this->elevadorSelecionado);
        if ($status == "Bloqueado" || $status == "Subindo" || $status == "Descendo"){
            $resp = $this->objElevadorModel->liberaElevadorSelecionado($this->elevadorSelecionado);
            if ($resp > 0){
                $this->changeMsg("Elevador Liberado");
            }
        }
    }
    public function getElevadorSelecionado(){
        return $this->elevadorSelecionado;
    }
    
    public function getMsgPainel(){
        return $this->msgPainel;
    }
    public function setIdChamada($id){
        $this->idChamada = $id;
    }
}
//$t = new elevadorController(null,null,8);
//$t->setElevadorSelecionado(1);
//$t->setIdAndarDestino(7);
//$t->levarElevador();