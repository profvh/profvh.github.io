<?php
namespace Controller;

//descomentar a linha abaixo para testar a classe diretamente, sem usar phpunit
require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use).

use Model\elevadorModel, ADO\andarADO, Model\chamadaModel, Model\andarModel, Model\msgModel;
/**
 * Description of elevadorController
 *
 * @author tatuapu
 */
class painelExternoController {
    
    private $idAndar;
    private $objMsgModel;
    
    public function __construct($idAndar) {
        $this->idAndar = $idAndar;
        $this->objMsgModel = new msgModel();
    }
    public function getMsg(){
        return $this->objMsgModel->pegaUltimaMsgAndar($this->idAndar);
    }
    public function getIdElevador(){
        $objElevadorModel = new elevadorModel();
        return $objElevadorModel->getElevadorBloqueadoAndar($this->idAndar);
    }
    
}
