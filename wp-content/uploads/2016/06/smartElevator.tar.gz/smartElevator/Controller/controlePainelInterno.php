<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//descomentar a linha abaixo para testar a classe diretamente, sem usar phpunit
//require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use). 
require_once("painelInternoController.php");

use Controller\painelInternoController;

$idAndarFinal = $_REQUEST['andar'];
$idAndarAtual = $_REQUEST['andarAtual'];
$idElevador   = $_REQUEST['idElevador'];

$objPainelInternoController = new painelInternoController($idAndarFinal,$idAndarAtual,$idElevador);

//recebe true ou false. True para caso da movimentação ter ocorrido com sucesso
$t = $objPainelInternoController->movimentarElevador();

echo $t;

unset($objPainelExternoController);
