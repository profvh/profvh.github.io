<?php
namespace Controller;

//descomentar a linha abaixo para testar a classe diretamente, sem usar phpunit
//require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use).
require_once("elevadorController.php");

use Controller\elevadorController;
/**
 * Description of elevadorController
 *
 * @author tatuapu
 */
class painelInternoController {
    
    private $idAndarFinal;
    private $idAndarAtual;
    private $idElevador;
    
    
    public function __construct($idAndarFinal,$idAndarAtual,$idElevador) {
        $this->idAndarFinal = $idAndarFinal;
        $this->idAndarAtual = $idAndarAtual;
        $this->idElevador = $idElevador;        
    }
    
    public function movimentarElevador(){
                $t = new elevadorController(null,null,$this->idAndarAtual);
                $t->setElevadorSelecionado($this->idElevador);
                $t->setIdAndarDestino($this->idAndarFinal);
                $t->levarElevador();
    }
    
}
