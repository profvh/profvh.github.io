-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Máquina: localhost
-- Data de Criação: 02-Jun-2016 às 14:03
-- Versão do servidor: 5.5.49-0ubuntu0.14.04.1
-- versão do PHP: 5.5.9-1ubuntu4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de Dados: `smartElevator`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `andar`
--

CREATE TABLE IF NOT EXISTS `andar` (
  `idAndar` int(11) NOT NULL AUTO_INCREMENT,
  `nroAndar` int(11) NOT NULL,
  `statusAndar` enum('Ativo','Inativo') NOT NULL DEFAULT 'Inativo',
  PRIMARY KEY (`idAndar`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Extraindo dados da tabela `andar`
--

INSERT INTO `andar` (`idAndar`, `nroAndar`, `statusAndar`) VALUES
(1, 1, 'Ativo'),
(2, 2, 'Ativo'),
(3, 3, 'Ativo'),
(4, 4, 'Ativo'),
(5, 5, 'Ativo'),
(6, 6, 'Ativo'),
(7, 7, 'Ativo'),
(8, 8, 'Ativo');

-- --------------------------------------------------------

--
-- Estrutura da tabela `chamada`
--

CREATE TABLE IF NOT EXISTS `chamada` (
  `idChamada` int(11) NOT NULL AUTO_INCREMENT,
  `dataHora` datetime NOT NULL,
  `idAndar` int(11) NOT NULL,
  `statusChamada` enum('Nova','Em Curso','Concluída') NOT NULL COMMENT 'Nova: chamada criada, aguardando o elevador selecionado chegar; Em Curso: Passageiro já foi pego, e elevador está em movimento; Concluída: passageiro já foi entregue.',
  `tpChamada` enum('Subir','Descer') NOT NULL,
  `idElevador` int(11) NOT NULL,
  PRIMARY KEY (`idChamada`),
  KEY `fk_chamada_andar_idx` (`idAndar`),
  KEY `fk_chamada_elevador` (`idElevador`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=177 ;

--
-- Extraindo dados da tabela `chamada`
--

INSERT INTO `chamada` (`idChamada`, `dataHora`, `idAndar`, `statusChamada`, `tpChamada`, `idElevador`) VALUES
(173, '2016-06-02 12:50:11', 8, 'Concluída', 'Descer', 1),
(174, '2016-06-02 12:53:10', 8, 'Concluída', 'Descer', 1),
(175, '2016-06-02 12:55:11', 8, 'Concluída', 'Descer', 1),
(176, '2016-06-02 12:56:56', 7, 'Concluída', 'Descer', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `elevador`
--

CREATE TABLE IF NOT EXISTS `elevador` (
  `idElevador` int(11) NOT NULL AUTO_INCREMENT,
  `tpElevador` enum('1','2','3') NOT NULL DEFAULT '2' COMMENT '1: Social, 2: Serviço, 3: Carga',
  `statusElevador` enum('Ativo','Bloqueado','Descendo','Subindo') NOT NULL DEFAULT 'Bloqueado',
  `cpPesoElevador` float DEFAULT NULL COMMENT 'Capacidade de carga em peso\n',
  `cpPessoasElevador` int(11) DEFAULT NULL COMMENT 'Capacidade de pessoas',
  `vlSubida` int(11) DEFAULT NULL COMMENT 'Velocidade de subida',
  `vlDescida` int(11) DEFAULT NULL,
  `idAndar` int(11) NOT NULL,
  PRIMARY KEY (`idElevador`),
  KEY `elevador_andar` (`idAndar`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `elevador`
--

INSERT INTO `elevador` (`idElevador`, `tpElevador`, `statusElevador`, `cpPesoElevador`, `cpPessoasElevador`, `vlSubida`, `vlDescida`, `idAndar`) VALUES
(1, '2', 'Ativo', 240, 3, 2, 3, 6),
(2, '2', 'Ativo', 400, 6, 2, 3, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `movimentacao`
--

CREATE TABLE IF NOT EXISTS `movimentacao` (
  `idMovimentacao` int(11) NOT NULL AUTO_INCREMENT,
  `idChamada` int(11) NOT NULL,
  `elevador_idElevador` int(11) NOT NULL,
  `qtdPessoas` int(11) NOT NULL,
  `pesoOperacao` float DEFAULT NULL,
  PRIMARY KEY (`idMovimentacao`),
  KEY `fk_movimentacao_chamada1_idx` (`idChamada`),
  KEY `fk_movimentacao_elevador1_idx` (`elevador_idElevador`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `msg`
--

CREATE TABLE IF NOT EXISTS `msg` (
  `idMsg` int(11) NOT NULL AUTO_INCREMENT,
  `msg` varchar(200) NOT NULL,
  `idChamada` int(11) NOT NULL,
  PRIMARY KEY (`idMsg`),
  KEY `fk_msg_chamada` (`idChamada`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=369 ;

--
-- Extraindo dados da tabela `msg`
--

INSERT INTO `msg` (`idMsg`, `msg`, `idChamada`) VALUES
(357, 'Elevador Bloqueado Para Envio', 175),
(358, 'Elevador a Caminho', 175),
(359, 'Elevador Chegou', 175),
(360, 'Elevador Descendo', 175),
(361, 'Elevador Chegou', 175),
(362, 'Elevador Liberado', 175),
(363, 'Elevador Bloqueado Para Envio', 176),
(364, 'Elevador a Caminho', 176),
(365, 'Elevador Chegou', 176),
(366, 'Elevador Descendo', 176),
(367, 'Elevador Chegou', 176),
(368, 'Elevador Liberado', 176);

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `chamada`
--
ALTER TABLE `chamada`
  ADD CONSTRAINT `chamada_ibfk_1` FOREIGN KEY (`idElevador`) REFERENCES `elevador` (`idElevador`),
  ADD CONSTRAINT `fk_chamada_andar` FOREIGN KEY (`idAndar`) REFERENCES `andar` (`idAndar`);

--
-- Limitadores para a tabela `elevador`
--
ALTER TABLE `elevador`
  ADD CONSTRAINT `elevador_ibfk_1` FOREIGN KEY (`idAndar`) REFERENCES `andar` (`idAndar`);

--
-- Limitadores para a tabela `movimentacao`
--
ALTER TABLE `movimentacao`
  ADD CONSTRAINT `fk_movimentacao_chamada1` FOREIGN KEY (`idChamada`) REFERENCES `chamada` (`idChamada`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_movimentacao_elevador1` FOREIGN KEY (`elevador_idElevador`) REFERENCES `elevador` (`idElevador`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `msg`
--
ALTER TABLE `msg`
  ADD CONSTRAINT `msg_ibfk_1` FOREIGN KEY (`idChamada`) REFERENCES `chamada` (`idChamada`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
