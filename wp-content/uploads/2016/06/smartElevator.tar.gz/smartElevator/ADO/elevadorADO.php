<?php

/*
 * @author Victor Hugo Lopes
 * @date = 2016/05/18
 * 
 */

namespace ADO;

//descomentar a linha abaixo para testar a classe diretamente, sem usar phpunit
//require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use). 

use ADO\AbstractBDPDO,    ADO\tbPropriedades,    Model\andarModel;
/**
 * Description of elevadorADO
 *
 * @author tatuapu
 */
class elevadorADO extends AbstractBDPDO {
    
    private $tbName;
    private $tbPropriedades;
    
    public function __construct(){
        $this->tbName = 'elevador';
        $t = new tbPropriedades();
        $this->tbPropriedades = $t->getTbPropriedades();//carregando propriedades das tabelas
        parent::__construct();//inicializa o BD na super classe
    }
    /**
     * Método para execução da query via PDO Prepared Statement, permitindo busca estilizada
     * passando os valores por parametros em array, separados da query
     * @param array $arrCols array com as colunas a serem consultadas
     * @param array $arrOps lista de operadores. Ex.: $arrCols[0] = idElevador; $arrOps[0] = '=' pra checar a igualdade (> < >= <= <> like)
     * @param array $arrVals array com os valores a serem testados pra cada coluna do $arrCols
     * @return retorna array com o fetchAll() ou NULL, caso ocorra erro no casamento dos arrays parâmetros
     */
    public function consultaElevadores($arrCols,$arrOps,$arrVals){
        $where = "";
        if ((count($arrCols) !== count($arrOps)) && (count($arrVals) !== count($arrCols)))//se não casar os arrays, não pode consultar
             return NULL;
        for($i=0;$i<count($arrCols);$i++){
            $where.= " ". $arrCols[$i] ." ". $arrOps[$i] . " ?";
            if ($i+1 < count($arrCols))//colocando vírgula até o penúltimo elemento
                $where.=" AND ";
        }
        $query = "SELECT * FROM {$this->tbName} WHERE " . $where ;
        $this->executaQueryPS($query, $arrVals);
        return $this->pegaSelect(); //devolve o array com os dados buscados
    }
    /**
     * busca todos os elevadores cadastrados
     * @return array com o fetchAll()
     */
    public function pegaTodosElevadores(){
        $query = "SELECT * FROM {$this->tbName} ORDER BY idElevador";
        $this->executaQuery($query);
        return $this->pegaSelect();
    }
    public function pegaElevadorEspecifico($id){
        $query = "SELECT * FROM {$this->tbName} WHERE idElevador = ?";
        $this->executaQueryPS($query, array($id));
        return $this->pegaSelect();
    }
    /**
     * Recebe o idElevador e retorna o status deste elevador
     * @param int $id representa o idElevador
     * @return string com o status "Ativo", "Bloqueado", "Subindo" ou "Descendo"
     */
    public function getStatusElevador($id){
        $resp = $this->pegaElevadorEspecifico($id);
        return $resp[0][2];//retornando exatamente a coluna statusElevador
    }
    /**
     * busca todos os elevadores cadastrados que estejam com status = "Ativo"
     * @return array com o fetchAll() para a busca
     */
    public function pegaElevadoresAtivos(){
        $query = "SELECT {$this->tbName}.*,andar.nroAndar FROM elevador inner join andar on "
                . "elevador.idAndar = andar.idAndar WHERE elevador.statusElevador='Ativo'";
        $this->executaQuery($query);
        return $this->pegaSelect();
    }
    public function setStatusElevador($status,$idElevador){
        $query = "UPDATE {$this->tbName} SET {$this->tbPropriedades[$this->tbName][2]} = "
        . "? WHERE {$this->tbPropriedades[$this->tbName][0]} = ?;";
        $resp = $this->executaQueryPS($query, [$status,$idElevador]);
        if($resp == true){
            return $this->contaLinhas();
        }else{
            return 0;
        }
    }
    private function changeIdAndar($idElevador, $nIdAndar){
        $nIdAndar;
        $query = "UPDATE {$this->tbName} SET {$this->tbPropriedades[$this->tbName][7]} = "
            . "? WHERE {$this->tbPropriedades[$this->tbName][0]} = ?;";
        $resp = $this->executaQueryPS($query, array($nIdAndar,$idElevador));
        if($resp == true){
            return $this->contaLinhas();
        }else{
            return 0;
        }
    }
    /**
     * movimenta o elevador 1 andar acima
     * @param type $idElevador
     * @return int $nIdAndar para permitir atualização no objeto elevador criado
     * ou 0 caso não seja possível incrementar
     */
    public function sobeElevador($idElevador){
        $objAndarModel = new andarModel();
        $ultAndar = $objAndarModel->getUltimoAndar();
        $elAtual = $this->pegaElevadorEspecifico($idElevador);
        //conferindo se há andar para incrementar
        if(($objAndarModel->getNroAndar($elAtual[0]['idAndar']) + 1) <= $ultAndar){
            //pegando o id do andar incrementado
            $nIdAndar = $objAndarModel->getIdAndar($objAndarModel->getNroAndar($elAtual[0]['idAndar']) + 1);
            //salvando o idAndar no elevador
            $this->changeIdAndar($idElevador,$nIdAndar);
            return $nIdAndar;
        }
        return 0;
    }
    /**
     * movimenta o elevador 1 andar abaixo
     * @param type $idElevador
     * @return int $nIdAndar para permitir atualização no objeto elevador criado
     * ou 0 caso não seja possível decrementar
     */
    public function desceElevador($idElevador){
        $objAndarModel = new andarModel();
        $primAndar = $objAndarModel->getPrimeiroAndar();
        $elAtual = $this->pegaElevadorEspecifico($idElevador);
        //conferindo se há andar para decrementar
        if(($objAndarModel->getNroAndar($elAtual[0]['idAndar']) - 1) >= $primAndar){
            //pegando o id do andar incrementado
            $nIdAndar = $objAndarModel->getIdAndar($objAndarModel->getNroAndar($elAtual[0]['idAndar']) - 1);
            //salvando o idAndar no elevador
            $this->changeIdAndar($idElevador,$nIdAndar);
            return $nIdAndar;
        }
        return 0;
    }
    /**
     * Pega o elevador que está bloqueado no andar especificado
     * @param int $idAndar
     * @return int idElevador.
     */
    public function getElevadorBloqueadoAndar($idAndar){
        $objAndarModel = new andarModel();
        
        $query = "SELECT * FROM  {$this->tbName}"
                . " WHERE statusElevador =  'Bloqueado' AND idAndar =? ";
        $this->executaQueryPS($query,array($idAndar));
        $r = $this->pegaSelect();
        
        return $r[0][0];
    }
    
}

//$t = new elevadorADO(); print_r($t->consultaElevadores(array('idElevador','tpElevador'), array('>=','='), array(1,2)));
//print_r($t->tbPropriedades->getTbPropriedades());
//var_dump($t->pegaElevadorEspecifico(1));
//echo $t->contaLinhas();
        



