<?php

/*
 * @author Victor Hugo Lopes
 * @date = 2016/05/18
 * 
 */

namespace ADO;

//descomentar a linha abaixo para testar a classe diretamente, sem usar phpunit
//require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use). 

use ADO\AbstractBDPDO,    ADO\tbPropriedades;
/**
 * Description of elevadorADO
 *
 * @author tatuapu
 */
class andarADO extends AbstractBDPDO {
    
    private $tbName;
    private $tbPropriedades;
    
    public function __construct(){
        $this->tbName = 'andar';
        $t = new tbPropriedades();
        $this->tbPropriedades = $t->getTbPropriedades($this->tbName);//carregando propriedades da tabela andar
        parent::__construct();//inicializa o BD na super classe
    }
    /**
     * Método para execução da query via PDO Prepared Statement, permitindo busca estilizada
     * passando os valores por parametros em array, separados da query
     * @param array $arrCols array com as colunas a serem consultadas
     * @param array $arrOps lista de operadores. Ex.: $arrCols[0] = idElevador; $arrOps[0] = '=' pra checar a igualdade (> < >= <= <> like)
     *          a função não está preparada para testar condições como "where id > 1 and id <=10"
     * @param array $arrVals array com os valores a serem testados pra cada coluna do $arrCols
     * @return retorna array com o fetchAll() ou NULL, caso ocorra erro no casamento dos arrays parâmetros
     */
    public function consultaAndares($arrCols,$arrOps,$arrVals){
        $where = "";
        if ((count($arrCols) !== count($arrOps)) && (count($arrVals) !== count($arrCols)))//se não casar os arrays, não pode consultar
             return NULL;
        for($i=0;$i<count($arrCols);$i++){
            $where.= " ". $arrCols[$i] ." ". $arrOps[$i] . " ?";
            if ($i+1 < count($arrCols))//colocando vírgula até o penúltimo elemento
                $where.=" AND ";
        }
        $query = "SELECT * FROM {$this->tbName} WHERE " . $where ;
        $this->executaQueryPS($query, $arrVals);
        return $this->pegaSelect(); //devolve o array com os dados buscados
    }
    /**
     * busca todos os andares cadastrados
     * @return array com o fetchAll() sendo array associativo e indexado juntos,
     * com um andar por linha do array
     */
    public function pegaTodosAndares(){
        $query = "SELECT * FROM {$this->tbName} "
                . "ORDER BY ".$this->tbPropriedades[0].", ".$this->tbPropriedades[1]; //consultando todos andares, ordenando pelo id, nroAndar
        $this->executaQuery($query);
        return $this->pegaSelect();
    }
    public function pegaAndarEspecifico($id){
        $query = "SELECT * FROM {$this->tbName} WHERE ".$this->tbPropriedades[0]." = ?";
        $this->executaQueryPS($query, array($id));
        return $this->pegaSelect();//devolvendo o array (fetchAll) da consulta realizada
    }
    public function getNroAndar($id){
        $r = $this->pegaAndarEspecifico($id);
        return $r[0]['nroAndar'];
    }
    public function getIdAndar($nro){
        $query = "SELECT * FROM {$this->tbName} WHERE nroAndar = ?";
        $this->executaQueryPS($query, array($nro));
        $r = $this->pegaSelect();
        return $r[0][0];
    }
    public function pegaUltimoAndar(){
        $query = "SELECT * FROM {$this->tbName} order by nroAndar desc Limit 0,1";
        $this->executaQuery($query);
        return $this->pegaSelect();
    }
    public function pegaPrimeiroAndar(){
        $query = "SELECT * FROM {$this->tbName} order by nroAndar Limit 0,1";
        $this->executaQuery($query);
        $r = $this->pegaSelect();
        return $r[0]['nroAndar'];
    }
    
}

//$t = new elevadorADO(); print_r($t->consultaElevadores(array('idElevador','tpElevador'), array('>=','='), array(1,2)));
//print_r($t->tbPropriedades->getTbPropriedades());
//var_dump($t->pegaElevadorEspecifico(1));
//echo $t->contaLinhas();
        



