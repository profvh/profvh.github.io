<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace ADO;

/**
 * Description of tbPropriedades
 * Carrega informações das tabelas do bd (v 1.0.0)
 * @author tatuapu
 */
class tbPropriedades {
    private $tbPropriedades;
    
    public function __construct(){
        $this->tbPropriedades['elevador']=['idElevador','tpElevador','statusElevador','cpPesoElevador','cdPessoasElevador','vlSubida','vlDescida','idAndar'];
        $this->tbPropriedades['andar'] = ['idAndar','nroAndar','statusAndar'];
        $this->tbPropriedades['chamada'] = ['idChamada','dataHora','idAndar','statusChamada','tpChamada','idElevador'];
        $this->tbPropriedades['movimentacao'] = ['idMovimentacao','idChamada','elevador_idElevador','qtdPessoas','pesoOperacao'];
        $this->tbPropriedades['msg'] = ['idMsg','msg','idChamada'];
    }

    public function getTbPropriedades($tb = null) {
        if ($tb !== null){
            return $this->tbPropriedades[$tb];
        }else{    
           return $this->tbPropriedades;
        }   
    }
    
    /**
     * Cria uma string com a lista de colunas pra usar em DML
     * @return a string das colunas separadas por vírgula
     */
    public function getColunasSQL($tp,$tb){
        $tabela = $this->tbPropriedades[$tb];
        $lista = "";
        
        if($tp == "insert"){
            for($i=1;$i<count($tabela);$i++){
                $lista .= $tabela[$i];
                if ($i+1<count($tabela)){
                    $lista.=",";
                }
            }
        }
        return $lista;
        
    }

}
