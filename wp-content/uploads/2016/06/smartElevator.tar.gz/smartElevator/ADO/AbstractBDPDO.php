<?php

/*
 * @author Victor Hugo Lopes
 * @date = 2016/05/18
 * 
 */

namespace ADO;
use PDO;
/**
 * Description: 
 * Classe abstrata com propriedades e métodos necessários a qualquer comunicação com o BD
 */
abstract class AbstractBDPDO extends PDO {
    //propriedades
    private $host    = NULL;
    private $usuario = NULL;
    private $senha   = NULL;
    private $bdNome  = NULL;
    private $mensagem= NULL;
    private $options = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
    private $PDOStatement = NULL;
    private $pdo = NULL;
    
    public function __construct() {
        $file = file("/var/www/smartElevator/ADO/conexao");//abrindo arquivo
        $exf = explode(",",$file[0]); //explodindo pela vírgula
        $this->host    = base64_decode($exf[0]); //carregando dados do bd
        $this->usuario = base64_decode($exf[1]); //decodificando criptografia em base64
        $this->senha   = base64_decode($exf[2]);
        $this->bdNome  = base64_decode($exf[3]);
        try {
            $this->pdo= new PDO("mysql:host={$this->host};dbname={$this->bdNome};charset=utf8", $this->usuario, $this->senha, $this->options);
        } catch (PDOException $e) {
            die("Erro ao contectar ao BD. Erro: " . $e->getMessage());
            return;
        }
        
     }
    public function __destruct() {
        $this->host    = NULL;
        $this->usuario = NULL;
        $this->senha   = NULL;
        $this->bdNome  = NULL;
    } 
    
    public function executaQuery($query) {
        $this->PDOStatement = NULL;//zerando execuções anteriores
        $this->PDOStatement = $this->pdo->prepare($query);
        return $this->PDOStatement->execute();
    }    
    /**
     * Método para execução da query via PDO Prepared Statement
     * passando os valores por parametros em array, separados da query
     * @param String $query Instrução SQL parametrizada com ?.
     * @param array $arrayDeValores Valores a serem substituídos nos ? da instrução.
     * @return boolean true ou false dependendo do resultado de execute()
     */
    function executaQueryPS($query, $arrayDeValores) {
        $this->PDOStatement = NULL;//zerando execuções anteriores
        $this->PDOStatement = $this->pdo->prepare($query);
        return $this->PDOStatement->execute($arrayDeValores);
    }
    /**
    * Método para retornar o número de linhas encontradas na última pesquisa realizada
     * ou o número de linhas afetadas num update/delete/insert
     * @return int representando o número de linhas encontradas no select
     **/
    public function contaLinhas() {
        return $this->PDOStatement->rowCount();
    }
    public function pegaSelect(){
        return $this->PDOStatement->fetchAll();
    }
    public function pegaUltimoId(){
        return $this->pdo->lastInsertId();
    }
}

