<?php

/*
 * @author Victor Hugo Lopes
 * @date = 2016/05/18
 * 
 */

namespace ADO;

//descomentar a linha abaixo para testar a classe diretamente, sem usar phpunit
//require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use). 
//dependendo da situação de teste ou implementação, é necessário usar require

use ADO\AbstractBDPDO,    ADO\tbPropriedades;
/**
 * Description of msgADO
 *
 * @author tatuapu
 */
class msgADO extends AbstractBDPDO {
    
    private $tbName;
    private $tbPropriedades;
    
    public function __construct(){
        $this->tbName = 'msg';
        $t = new tbPropriedades();
        $this->tbPropriedades = $t->getTbPropriedades($this->tbName);//carregando propriedades da tabela
        parent::__construct();//inicializa o BD na super classe
    }
    
    /**
     * busca todos os andares cadastrados
     * @return array com o fetchAll() sendo array associativo e indexado juntos,
     * com um andar por linha do array
     */
    public function pegaTodasMsgs(){
        $query = "SELECT * FROM {$this->tbName} "
                . "ORDER BY ".$this->tbPropriedades[0];
        $this->executaQuery($query);
        return $this->pegaSelect();
    }
    /**
     * salva uma nova mensagem
     * @param string $msg
     * @return int rowCount
     */
    public function setMsg($msg,$idChamada){
        $query = "INSERT INTO msg ({$this->tbPropriedades[1]},{$this->tbPropriedades[2]})"
        . " VALUES (?,?)";
        $this->executaQueryPS($query, array($msg,$idChamada));
        return $this->contaLinhas();
    }
    public function pegaUltimaMsg($idChamada){
        $query = "SELECT * FROM {$this->tbName} WHERE {$this->tbPropriedades[2]}=?"
        . " ORDER BY {$this->tbPropriedades[0]} DESC LIMIT 0,1";
        $this->executaQueryPS($query, array($idChamada));
        return $this->pegaSelect();
    }
    public function pegaUltimaMsgAndar($idAndar){
        $query = "SELECT * FROM {$this->tbName} inner join chamada on msg.idChamada = "
                . " chamada.idChamada inner join andar on chamada.idAndar = andar.idAndar"
                . " where chamada.idAndar = ? order by msg.idMsg desc limit 0,1";
        $this->executaQueryPS($query, array($idAndar));
        return $this->pegaSelect();
                
    }
    
}