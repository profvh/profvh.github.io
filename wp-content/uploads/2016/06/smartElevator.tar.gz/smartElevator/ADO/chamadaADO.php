<?php

/*
 * @author Victor Hugo Lopes
 * @date = 2016/05/27
 * 
 */

namespace ADO;

//descomentar a linha abaixo para testar a classe diretamente, sem usar phpunit
require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use). 

use ADO\AbstractBDPDO,    ADO\tbPropriedades;
/**
 * Description of chamadaADO
 *
 * @author tatuapu
 */
class chamadaADO extends AbstractBDPDO {
    
    private $tbName;
    private $tbPropriedades;
    
    public function __construct(){
        $this->tbName = 'chamada';
        $t = new tbPropriedades();
        $this->tbPropriedades = $t->getTbPropriedades();//carregando propriedades das tabelas
        parent::__construct();//inicializa o BD na super classe
    }
    
    /**
     * busca todas as chamadas cadastrados
     * @return array com o fetchAll()
     */
    public function pegaTodasChamadas(){
        $query = "SELECT * FROM {$this->tbName} ORDER BY {$this->tbPropriedades[$this->tbName][0]}";
        $this->executaQuery($query);
        return $this->pegaSelect();
    }
    public function pegaChamadaEspecifica($id){
        $query = "SELECT * FROM {$this->tbName} WHERE {$this->tbPropriedades[$this->tbName][0]} = ?";
        $this->executaQueryPS($query, array($id));
    }
    /**
     * procura a última chamada nova para o referido andar
     * 
     * @param int $idAndar
     * @return int idChamada
     */
    public function pegaUltimaChamadaNovaIdAndar($idAndar){
        $query= "SELECT * FROM {$this->tbName} WHERE statusChamada = 'Nova'"
                . " and idAndar = ? order by idChamada desc Limit 0,1";
        $this->executaQueryPS($query, array($idAndar));
        $resp = $this->pegaSelect();
        print_r($resp);
        return $resp[0][0];
    }
    
    /**
     * busca todas as chamadas cadastrados Novas
     * @return array com o fetchAll()
     */
    public function pegaTodasNovas(){
        $query = "SELECT * FROM {$this->tbName} WHERE {$this->tbPropriedades[$this->tbName][3]} = 'Nova'"
        . " ORDER BY {$this->tbPropriedades[$this->tbName][0]}";
        $this->executaQuery($query);
        return $this->pegaSelect();
    }
    
    /**
     * Cria uma nova chamada no BD
     * @return o numRows, indicando a quantidade de linhas afetadas.
     */
    public function criaChamada($idAndar,$tpChamada, $idElevSelecionado){
        $t = new tbPropriedades();
        $date = date('Y-m-d H:i:s');
        $query = "INSERT INTO {$this->tbName} ({$t->getColunasSQL("insert",$this->tbName)})"
        . " VALUES (?,?,?,?,?);";
        $resp = $this->executaQueryPS($query, [$date, $idAndar, "Nova", $tpChamada, $idElevSelecionado]);
        if($resp == true){
            return $this->contaLinhas();
        }else{
            return 0;
        }
    }
    public function getUltimaChamadaCriada(){
        return $this->pegaUltimoId();
    }
    /**
     * Altera uma chamada, mudando o status "Novo" para "Em Curso"
     * É executada quando o elevador chegou ao andar da chamada
     * e pegou o passageiro
     * @return o numRows, indicando a quantidade de linhas afetadas.
     * retornando 1 indica que a transação foi bem sucedida, e retornando
     * 0 indica erro
     */
    public function setChamadaEmCurso($idChamada){
        
        $query = "UPDATE {$this->tbName} SET {$this->tbPropriedades[$this->tbName][3]}"
        . "= 'Em Curso' WHERE {$this->tbPropriedades[$this->tbName][0]}=?";
        
        $resp = $this->executaQueryPS($query, [$idChamada]);
        if($resp == true){
            return $this->contaLinhas();
        }else{
            return 0;
        }
    }
    /**
     * Altera uma chamada, mudando o status "Em Curso" para "Concluída"
     * É executada quando o elevador chegou ao andar final e entrega
     * o passageiro
     * @return o numRows, indicando a quantidade de linhas afetadas.
     * retornando 1 indica que a transação foi bem sucedida, e retornando
     * 0 indica erro
     */
    public function setChamadaConcluida($idChamada){
        
        $query = "UPDATE {$this->tbName} SET {$this->tbPropriedades[$this->tbName][3]}"
        . "= 'Concluída' WHERE {$this->tbPropriedades[$this->tbName][0]}=?";
        
        $resp = $this->executaQueryPS($query, [$idChamada]);
        if($resp == true){
            return $this->contaLinhas();
        }else{
            return 0;
        }
    }   
    
}
//
//$t = new chamadaADO();
//echo $t->criaChamada(7,"Descer",1);
        



