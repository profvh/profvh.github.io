<?php
namespace ADO;
require("./vendor/autoload.php");

use ADO\elevadorADO;

use PHPUnit_Framework_TestCase as PHPUnit;

class elevadorADOTest extends PHPUnit{
    public function testDeveEncontrarCorretamenteElevador1(){
        $t = new elevadorADO();
        //print_r($t->consultaElevadores(array('idElevador','tpElevador'), array('>=','='), array(1,2)));
        $t->pegaElevadorEspecifico(1);
        $this->assertEquals(1,$t->contaLinhas());
    }
    public function testDeveEncontrarElevador1e2QueryPS(){
        $t = new elevadorADO();
        $r = $t->consultaElevadores(array('idElevador'), array('>='), array(1));
        $this->assertEquals(2,count($r));
    }
}

