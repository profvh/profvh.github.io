<link rel="stylesheet" href="estiloso.css">

<iframe id="iframe" src="edificio.php" width="400px" height="600px" frameborder="0" scrolling="NO" >
    
</iframe>

<iframe id="iframe" src="painel.php" width="500px" height="600px" frameborder="0" scrolling="NO" style="position:absolute; right:0px; top:0px;" >
</iframe>    
    
