<style>
    .painel{
        width: 480px;
        height: 200px;
        padding-top: 10px;
        text-align: center;
        background-image: url("img/metal.jpg");
    }
    .botoes input{
        width:200px;
        height: 80px;
    }
    .botoes select{
        width:60px;
        height: 80px;
    }
    #box{
        width:400px;
        height: 80px;
        margin:0px;
        border:none;
        color: black;
        padding:3px;
        margin:5px;
        color: #ff0000;
        font-size: 20px;
        text-align: center;
    }
    input[type="text"], textarea {

  background-color : black; 
  color: #ff0000;

}
</style>
<script type="text/javascript" src="../JS/jquery-1.12.4.js" ></script>
<script type="text/javascript" src="../JS/controleElevador.js" ></script>
<script type="text/javascript" src="../JS/painelExternoElevador.js" ></script>
<script type="text/javascript">
    controle = new controleElevador();
    painelExterno = new painelExternoElevador();
    cont = 0;
    idAndar = 0;
    porta = "fechada";
    function chamaElevador(tp){
        cont=0;
        //get value of selected option
        idAndar = $('#andar').val();
        if (idAndar == 0){
            alert('Selecione um Andar Válido');
        }else{
            controle.chamaElevador(tp,idAndar);
        }    
        //chamando a função com timer de 1 segundo
        setTimeout('checkPainel()',1000);
    }
    function checkPainel(){
        //$('#box').val(cont);
        idAndar = $('#andar').val();
        t = painelExterno.getMsg(idAndar);
        $('#box').val(t);
        if(t=="Elevador Chegou" && porta=="fechada"){
            abrePorta();
            porta = "aberta";
        }else if(t!=="Elevador Chegou" && porta=="aberta"){
            fechaPorta();
            porta="fechada";
        }
        
        //chamando recursivamente com timer de 1 segundo
        setTimeout('checkPainel()',2000);
    }
    function fechaPorta(){
        document.getElementById('painelInterno').src="painelInterno.php?porta=fechada&idAndar="+idAndar;
    }
    function abrePorta(){
        document.getElementById('painelInterno').src="painelInterno.php?porta=aberta&idAndar="+idAndar;
    }
</script>    
    
<?php
require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use).    
use Model\andarModel;    
    $objAndarModel = new andarModel();
    $andares = $objAndarModel->getAllAndares();    
?>
<div class="painel">
    <div id="msg">
        <input type="text" id="box" value="..." />
    </div>
    <div class="botoes">
        <select name="andar" id="andar">
            <option value="0">0</option>
            <?php
                foreach($andares as $andar){
                    echo "<option value='".$andar['idAndar']."'>".$andar['nroAndar']."</option>";
                }
            ?>
        </select>
        <input type="button" name="subir" id="subir" value="subir" onclick="chamaElevador('subir');"/>
        <input type="button" name="descer" id="descer" value="descer" onclick="chamaElevador('descer');"/>
    </div>
</div>

<iframe src="painelInterno.php?porta=fechada" id="painelInterno" width="500px" height="400px" frameborder="0" scrolling="NO" style="position:absolute; right:0px; bottom:0px;" >    
    
</iframe>
