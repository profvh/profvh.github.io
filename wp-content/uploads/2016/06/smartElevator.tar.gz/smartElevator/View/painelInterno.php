 
<script type="text/javascript" src="../JS/jquery-1.12.4.js" ></script>
<script type="text/javascript" src="../JS/controleElevador.js" ></script>
<script type="text/javascript" src="../JS/painelInternoElevador.js" ></script>
<script type="text/javascript">
    controle = new controleElevador();
    painelInterno = new painelInternoElevador();
    
    function clicado(idAndarFinal,idAndarAtual,idElevador){
        criaId = "#btn"+idAndarFinal;
        $(criaId).attr("disabled", "disabled");
        painelInterno.btnPainelInternoClicado(idAndarFinal,idAndarAtual,idElevador);
    }
</script> 
<?php
require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use).    
use Model\andarModel,    Model\elevadorModel;
 $objAndarModel = new andarModel();
 $andares = $objAndarModel->getAllAndares();   
 $objElevadorModel = new elevadorModel();
 

if (isset($_GET['porta'])){
    if ($_GET['porta'] == 'fechada'){
        echo "<img src='img/portaElevadorFechada.jpg' />";
    }else{
        /*//_____________________________________________________________________-*/   
        $idElevador = $objElevadorModel->getElevadorBloqueadoAndar($_GET['idAndar']);
        echo "<br><br>Selecione o Andar: <br>";
        foreach($andares as $andar){
            if($_GET['idAndar']==$andar['idAndar']){
                echo "<input type='button' name='btn{$andar['idAndar']}' id='btn{$andar['idAndar']}' value=' {$andar['nroAndar']} ' disabled=disabled />";
            }else{
                echo "<input type='button' name='btn{$andar['idAndar']}' id='btn{$andar['idAndar']}' value=' {$andar['nroAndar']} ' onClick='clicado({$andar['idAndar']},{$_GET['idAndar']},{$idElevador});' />";
            }    
        }

        /*//__________________________________________________________________---*/
        
    }
}