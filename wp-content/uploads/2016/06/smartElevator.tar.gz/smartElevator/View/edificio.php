<link rel="stylesheet" href="estiloso.css">
<meta http-equiv="refresh" content="1; URL=edificio.php">
<div id="predio">
    <div class="andar-predio"></div>
<?php


/* 
 * constroi um simulador do elevador
 */
//descomentar a linha abaixo para testar a classe diretamente, sem usar phpunit
require "../vendor/autoload.php";//garante o carregamento das classes importadas com uso de namespaces (use). 

use Model\andarModel,    Model\elevadorModel;

$objAndarModel = new andarModel();
//pegando todos andares cadastrados
$andares = $objAndarModel->getAllAndares();

$objElevadorModel = new elevadorModel();
//pegando todos elevadores cadastrados
$elevadores = $objElevadorModel->getAllElevadores();
$ele = array();
$and = array();
foreach($elevadores as $elevador){
   $ele[$elevador['idAndar']] = $elevador['idElevador'];
   $and[] = $elevador['idAndar'];
}
arsort($andares);
foreach($andares as $andar){
    echo "<div class'porta-andar-predio'>";
    if(in_array($andar['idAndar'], $and)){
        echo "<div class='elevador".  pintaElevadorStatus($ele[$andar['idAndar']])."'>{$ele[$andar['idAndar']]}</div>";
    }else{
        echo "<div class='nelevador'></div>";
    }    
    echo "<div class='andar-predio maior'>"
    ."<div class='janelas'></div>"
    ."<div class='janelas'></div>"
    ."<div class='janelas'></div>"
    ."<div class='janelas'></div>"
    . "</div>";
    echo "</div>";
}

function pintaElevadorStatus($id){
    $elM = new elevadorModel();
    $se = $elM->getStatusElevadorEspecifico($id);
    switch($se){
        case "Ativo":
            return ' elevador-ativo';
            break;
        case "Bloqueado":
            return ' elevador-bloqueado';
            break;
        case "Subindo":
            return ' elevador-subindo';
            break;
        case "Descendo":
            return ' elevador-descendo';
            break;
    }
    
}
?>
</div>