<?php
namespace classes;

use ADO\tbPropriedades;
/**
 * Description of elevador
 *
 * @author tatuapu
 */
class elevador {
    private $tbPropriedades;
    private $tbName;
    private $idElevador;
    private $tpElevador;
    private $cpPesoElevador;
    private $cpPessoasElevador;
    private $vlSubida;
    private $vlDescida;
    private $idAndar;
    
    public function __construct($args){
        $this->tbName = 'elevador';
        $t = new tbPropriedades();
        $this->tbPropriedades = $t->getTbPropriedades($this->tbName);//carregando propriedades da tabela
        $this->setIdElevador($args[0]);
        $this->setTpElevador($args[1]);
        $this->setCpPesoElevador($args[3]);
        $this->setCpPessoasElevador($args[4]);
        $this->setVlSubida($args[5]);
        $this->setVlDescida($args[6]);
        $this->setIdAndar($args[7]);
    }
    public function setTbName($tbName) {
        $this->tbName = $tbName;
    }

    public function setIdElevador($idElevador) {
        $this->idElevador = $idElevador;
    }

    public function setTpElevador($tpElevador) {
        $this->tpElevador = $tpElevador;
    }

    public function setCpPesoElevador($cpPesoElevador) {
        $this->cpPesoElevador = $cpPesoElevador;
    }

    public function setCpPessoasElevador($cpPessoasElevador) {
        $this->cpPessoasElevador = $cpPessoasElevador;
    }

    public function setVlSubida($vlSubida) {
        $this->vlSubida = $vlSubida;
    }

    public function setVlDescida($vlDescida) {
        $this->vlDescida = $vlDescida;
    }

    public function setIdAndar($idAndar) {
        $this->idAndar = $idAndar;
    }

    public function getTbName() {
        return $this->tbName;
    }

    public function getIdElevador() {
        return $this->idElevador;
    }

    public function getTpElevador() {
        return $this->tpElevador;
    }

    public function getCpPesoElevador() {
        return $this->cpPesoElevador;
    }

    public function getCpPessoasElevador() {
        return $this->cpPessoasElevador;
    }

    public function getVlSubida() {
        return $this->vlSubida;
    }

    public function getVlDescida() {
        return $this->vlDescida;
    }

    public function getIdAndar() {
        return $this->idAndar;
    }


}
