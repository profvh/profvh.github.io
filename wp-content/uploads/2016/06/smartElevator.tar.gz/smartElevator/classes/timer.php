<?php 
namespace classes;

class timer { 
    private $seconds;
    private $action;
    private $ti;//time initial
    private $tf;//time final
    private $c;//expected time
    
    public function __construct() {
        $this->ti=0;
        $this->tf=0;
        $this->seconds=0;
        $this->action='stop';
    }
    /**
     * captura o tempo em segundos para rodar o cronômetro
     * inicializa as variáveis necessárias
     * chama o counter()
     * @param int $c representa o tempo em segundos pro timer aguardar
     */
    public function start($c){
        $this->c = $c;
        $this->action='start';
        $this->seconds=0;
        $this->ti = time();
        $this->tf = 0;
        $this->counter(); 
    }
    /**
     * description of method counter()
     * This method is performed to get the current time using the php function 
     * "time ()", assigning the value in the variable seconds until the time 
     * (in seconds) has been reached
     * @param haven't
     * @return elapsed seconds
     */
    private function counter(){
        do{
            $this->seconds = time();
            if (($this->seconds - $this->ti)%60 == $this->c){
                $this->action='stop';
                $this->tf= $this->seconds;
            }
        }while($this->action=='start');
        return $this->getElapsedSeconds();
    }
    public function getElapsedSeconds(){
        return ($this->tf - $this->ti)%60;
    }
} 
/**
 * exemplo de uso da classe
 */
//$t = new Timer();
//$t->start(4);
//echo "Tempo decorrido apos solicitacao: ".$t->getElapsedSeconds();
