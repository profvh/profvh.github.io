/* global expect */

describe("controleBasicoElevador", function() {
    it("Deve Chamar Elevador Subir", function (){
      var elevador1 = new controleElevador(); //instancia o objeto da classe sob teste
      
      expect(elevador1.chamaElevador(1)).toEqual("pegaElevadorEspecifico");	
    });  
});
