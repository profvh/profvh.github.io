var conversorUnidades = function (actual, type){
	var valorAtual;
	var tipoAtual;
	var distance;

	this.valorAtual = actual;
	this.tipoAtual = type;
	this.distance = ["km","m","cm","mm","in"];

	this.getValorAtual = function(){
		return this.valorAtual;
	}
	this.getTipoAtual = function(){
		return this.tipoAtual;
	}

	this.converte = function (ntype){
			ntp = this.distance.indexOf(ntype);//pegando um index para o novo tipo pedido
			if (ntp >=0){
				switch(ntp){
					case 0:
						return this.toKm();
						break;
					case 1:
						return this.toM();
						break;
					case 2:
						return this.toCm();
						break;	
					case 3:
						return this.toMm();
						break;
					case 4:
						return this.toIn();
						break;	
					default:
						return "Unidade de Distância Incompatível";			
				}
			}else{
				return "Conversão Inválida";
			}	
	}
	this.toCm = function(){
		atp = this.distance.indexOf(this.tipoAtual);//pegando um index para o novo tipo pedido	
				switch(atp){
					case 0:
						return this.valorAtual * 100000;
						break;
					case 1:
						return this.valorAtual * 100;
						break;
					case 2:
						return this.valorAtual;
						break;	
					case 3:
						return this.valorAtual * 0.1;
						break;
					case 4:
						return this.valorAtual * 2.54;
						break;	
					default:
						return "Unidade de Distância Incompatível";			
				}
	}
	this.toMm = function(){
		if (this.tipoAtual == "km")
			return this.valorAtual * 100000;
		else if (this.tipoAtual == "m")
			return this.valorAtual * 100;
		else if (this.tipoAtual == "in")
			return this.valorAtual * 25.4;
		else if (this.tipoAtual == "mm")
			return this.valorAtual;
	}
}