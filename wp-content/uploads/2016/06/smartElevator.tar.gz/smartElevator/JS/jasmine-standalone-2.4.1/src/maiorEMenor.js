var maiorEMenor = function (){
	var menor;
	var maior;
	this.encontra = function(nums){
		menor = Number.MAX_VALUE;
		maior = Number.MIN_VALUE;	
		nums.forEach(function(num){
				if (num < menor) menor = num;
				else if (num > maior) maior = num;
			});
	}
	this.pegaMenor = function(){
		return menor;	
	}
	this.pegaMaior = function(){
		return maior;	
	}
}