/* 
 * 
 * Permite montar um painel indicador interno
 * no qual o usuário pode selecionar o andar.
 * @author Victor Hugo Lopes
 * @date 2016-05-22
 */

/**
 * método btnPainelInternoClicado. Pra funcionar aguardando um retorno, propriedade
 * async deve ser false. Mas só sendo true é que temos assincronismos real.
 * @returns {painelInternoElevador.clazz}
 */
var painelInternoElevador = function(){
    var clazz = {
         btnPainelInternoClicado:function(idAndarFinal,idAndarAtual,idE){
            var retorno;
            $.ajax({
                    type: "POST",
                    url: "http://localhost/smartElevator/Controller/controlePainelInterno.php",
                    data: {andar:idAndarFinal,andarAtual:idAndarAtual,idElevador:idE},
                    dataType: "text",
                    async: true,
                    success: function(resp){
                        retorno = resp;
                    }
                });
            return retorno;
        }
    }
    return clazz;
}

//var controleElevador = function(){
    
//function controleElevador(){
//	var retornoAjax;
//	var clazz = {
//                 setRetornoAjax:function(t){
//                    retornoAjax = t;
//                    alert(retornoAjax);
//                },
//		chamaElevador:function(tp){
//                    retornoAjax = null;
//			$.ajax({
//                            type: "POST",
//                            url: "http://localhost/smartElevator/Controller/controleElevador.php",
//                            data: {action:"pegaElevadorEspecifico",idElevador:1},
//                            dataType: "text",
//                            success : function(txt){
//                                controleElevador.setRetornoAjax(txt);
//                            }
//                        });  
//		}             
//	};
//	return clazz;
//}