/* 
 * 
 * controle das funções do elevador
 * @author Victor Hugo Lopes
 * @date 2016-05-22
 */

/**
 * método chamaElevador. Pra funcionar aguardando um retorno, propriedade
 * async deve ser false. Mas só sendo true é que temos assincronismos real.
 * @returns {controleElevador.clazz}
 */
var controleElevador = function(){
    var clazz = {
         chamaElevador:function(tpChamada,idAndar){
            var retorno;
            $.ajax({
                    type: "POST",
                    url: "http://localhost/smartElevator/Controller/controleElevador.php",
                    data: {action:"chamarElevador",tp:tpChamada,andar:idAndar},
                    dataType: "text",
                    async: true,
                    success: function(resp){
                        retorno = resp;
                    }
                });
            return retorno;
        }
    }
    return clazz;
}

//var controleElevador = function(){
    
//function controleElevador(){
//	var retornoAjax;
//	var clazz = {
//                 setRetornoAjax:function(t){
//                    retornoAjax = t;
//                    alert(retornoAjax);
//                },
//		chamaElevador:function(tp){
//                    retornoAjax = null;
//			$.ajax({
//                            type: "POST",
//                            url: "http://localhost/smartElevator/Controller/controleElevador.php",
//                            data: {action:"pegaElevadorEspecifico",idElevador:1},
//                            dataType: "text",
//                            success : function(txt){
//                                controleElevador.setRetornoAjax(txt);
//                            }
//                        });  
//		}             
//	};
//	return clazz;
//}